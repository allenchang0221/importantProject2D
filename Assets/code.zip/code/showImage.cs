using System.Collections;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using TMPro;
using UnityEngine;
using UnityEngine.SceneManagement;
using UnityEngine.UI;

public class showImage : MonoBehaviour
{
    public RawImage myRawImage;
    public TextMeshProUGUI showYourAns;
    Texture2D texture;
    public static char correct = 'A';
    public Vector2 Vector2 = new Vector2();

    public static char ans = 'Z';
    void Start()
    {
        int n = 2;
        //List<Texture2D> files = Resources.LoadAll<Texture2D>("electronic").ToList();
        //string allFileName = string.Join("{", files.Select(f => f.name));
        //File.WriteAllText(Path.Combine(Application.dataPath, "Resources/electronic.txt"), allFileName);
        List<string> allFilesName =File.ReadAllText(Path.Combine(Application.dataPath, "Resources/electronic.txt")).Split("{",System.StringSplitOptions.RemoveEmptyEntries).ToList();
        //���J Resources ��Ƨ����W�� electronic ���Ϥ�
        texture = Resources.Load<Texture2D>($"electronic/{allFilesName[Random.Range(0, allFilesName.Count)]}");

        if (texture != null)
        {
            myRawImage.texture = texture;
            //myRawImage.GetComponent<AspectRatioFitter>().aspectRatio = texture.width / texture.height;
            //myRawImage.SetNativeSize();
            float longSide = Mathf.Max((float)texture.width, (float)texture.height);
            myRawImage.transform.localScale =10* new Vector2((float)texture.width / longSide, (float)texture.height*2 / longSide);
            //Vector2 = myRawImage.rectTransform.sizeDelta;

        }
        correct = texture.name.Last();
        //Debug.Log(texture.name);
    }
    private void Update()
    {
    }
    public void chooseAnswer(GameObject gameObject)
    {
        ans = gameObject.name[0];
        showYourAns.text = "YOUR ANSWER:  "+ans.ToString();
    }
    public void submit()
    {
        SceneManager.LoadScene("showIsTrue");
    }
}
